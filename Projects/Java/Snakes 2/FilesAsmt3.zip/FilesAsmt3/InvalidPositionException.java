public class InvalidPositionException extends RuntimeException {
	public InvalidPositionException(String msg) {
		super(msg);
	}
}